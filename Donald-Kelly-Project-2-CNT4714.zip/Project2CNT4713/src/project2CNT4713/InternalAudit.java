/* Donald Kelly
Course: CNT 4714 Spring 2024
Assignment title: Project 2 – Synchronized, Cooperating Threads Under Locking
Due Date: February 11, 2024
*/

package project2CNT4713;

import java.util.Random;

public class InternalAudit implements Runnable {
    private TheBank bank;
    private static final int MAXSLEEPTIME = 1500;
    private Random random;

    public InternalAudit(TheBank bank) {
        this.bank = bank;
        this.random = new Random();
    }

    public void run() {
        // Add logic to perform internal audit
        while (true) {
            try {
                // Sleep for a random amount of time
                Thread.sleep(random.nextInt(MAXSLEEPTIME) + 1);
                // Run the audit
                bank.internalAudit();
            } catch (InterruptedException exception) {
                System.out.println("Exception thrown by InternalAudit");
            }
        }
    }
}
