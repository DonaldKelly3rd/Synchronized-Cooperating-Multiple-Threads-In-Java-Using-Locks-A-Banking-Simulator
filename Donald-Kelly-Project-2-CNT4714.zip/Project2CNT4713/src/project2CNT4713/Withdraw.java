/* Donald Kelly
Course: CNT 4714 Spring 2024
Assignment title: Project 2 – Synchronized, Cooperating Threads Under Locking
Due Date: February 11, 2024
*/

package project2CNT4713;

import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

public class Withdraw implements Runnable {
    private TheBank bank;
    private Random random;
    private static final int MAXSLEEPTIME = 500;
    private static final AtomicInteger withdrawCounter = new AtomicInteger(0);
    private final int agentNumber;

    public Withdraw(TheBank bank) {
        this.bank = bank;
        this.random = new Random();
        this.agentNumber = withdrawCounter.incrementAndGet();
    }

    public void run() {
        // Add logic to withdraw money from the bank account
        while (true) {
            try {
                // Generate a random amount to withdraw (between $1 and $99)
                int amount = random.nextInt(99) + 1;
                // Withdraw the amount from the account
                bank.withdraw(amount, "WT" + agentNumber);
                // Sleep for a random amount of time
                Thread.sleep(random.nextInt(MAXSLEEPTIME) + 1);
            } catch (InterruptedException exception) {
                System.out.println("Exception thrown withdrawing!");
            }
        }
    }
}
