/* Donald Kelly
Course: CNT 4714 Spring 2024
Assignment title: Project 2 – Synchronized, Cooperating Threads Under Locking
Due Date: February 11, 2024
*/

package project2CNT4713;

// Bank interface specifies abstract methods to define the allowed behaviors on a bank account.
public interface TheBank {
    // Method to deposit money into the account
    // @param amount: the amount to deposit
    // @param threadName: the name of the thread making the deposit
    public abstract void deposit(int amount, String threadName);

    // Method to withdraw money from the account
    // @param amount: the amount to withdraw
    // @param threadName: the name of the thread making the withdrawal
    public abstract void withdraw(int amount, String threadName);

    // Method to log flagged transactions independently into a log file
    // @param amount: the amount of the transaction
    // @param threadName: the name of the thread making the transaction
    // @param transactionType: the type of thread making the transaction ("D" for deposit, "W" for withdrawal)
    public abstract void flaggedTransaction(int amount, String threadName, String transactionType);

    // Method for internal banking audit examining balance only
    public abstract void internalAudit();

    // Method for external banking audit by the Treasury Department examining balance only
    public abstract void treasuryAudit();
}
