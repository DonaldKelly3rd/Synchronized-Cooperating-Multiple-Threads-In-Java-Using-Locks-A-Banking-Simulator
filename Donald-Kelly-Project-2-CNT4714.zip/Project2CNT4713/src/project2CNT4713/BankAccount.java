package project2CNT4713;

import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.concurrent.locks.Lock;
import java.util.concurrent.locks.ReentrantLock;
import java.util.concurrent.atomic.AtomicInteger;

public class BankAccount implements TheBank {
    private Lock lock;
    private double balance;
    private int transactionCount; // Track the number of transactions since the last internal audit
    private AtomicInteger transactionIdCounter; // Counter for generating transaction IDs

    // Constructor initializes the lock, balance, transaction count, and transaction ID counter
    public BankAccount() {
        lock = new ReentrantLock();
        balance = 0;
        transactionCount = 0;
        transactionIdCounter = new AtomicInteger(1); // Start transaction ID counter at 1
    }

    // Method to deposit money into the account
    @Override
    public void deposit(int amount, String threadName) {
        lock.lock();
        try {
            // Update balance and transaction count
            balance += amount;
            transactionCount++;
            // Generate unique transaction ID
            int transactionId = transactionIdCounter.getAndIncrement();
            // Prepare output string
            String output = "Agent " + threadName + " deposits $" + amount + "   (+) Balance is $" + balance + " (Transaction ID: " + transactionId + ")";
            // Print to console and write to file
            System.out.println(output);
            writeToFile(output);
            // Check if the deposit is flagged
            if (amount > 350) {
                flaggedTransaction(amount, threadName, "D");
                output = "*** Flagged Transaction - Deposit by " + threadName + " in excess of $" + amount + " USD";
                System.out.println(output);
                writeToFile(output);
            }
        } finally {
            lock.unlock();
        }
    }

    // Method to withdraw money from the account
    @Override
    public void withdraw(int amount, String threadName) {
        lock.lock();
        try {
            // Check if there are sufficient funds
            if (balance >= amount) {
                // Update balance and transaction count
                balance -= amount;
                transactionCount++;
                // Generate unique transaction ID
                int transactionId = transactionIdCounter.getAndIncrement();
                // Prepare output string
                String output = "Agent " + threadName + " withdraws $" + amount + "  (-) Balance is $" + balance + " (Transaction ID: " + transactionId + ")";
                // Print to console and write to file
                System.out.println(output);
                writeToFile(output);
                // Check if the withdrawal is flagged
                if (amount > 75) {
                    flaggedTransaction(amount, threadName, "W");
                    output = "*** Flagged Transaction - Withdrawal by " + threadName + " in excess of $" + amount + " USD";
                    System.out.println(output);
                    writeToFile(output);
                }
            } else {
                // Insufficient funds, output error message
                String output = "Agent " + threadName + " withdraws $" + amount + "  (-) Balance is $" + balance
                        + " (*****) WITHDRAWAL BLOCKED INSUFFICIENT FUNDS!!!";
                System.out.println(output);
                writeToFile(output);
            }
        } finally {
            lock.unlock();
        }
    }

    // Method to log flagged transactions to a file
    @Override
    public void flaggedTransaction(int amount, String threadName, String transactionType) {
        // Log flagged transactions to transactions.csv file
        String fileName = "C:\\Users\\donal\\OneDrive\\Desktop\\transactions.csv";
        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName, true))) {
            writer.println("*** Flagged Transaction - " + (transactionType.equals("D") ? "Deposit" : "Withdrawal")
                    + " by " + threadName + " in excess of $" + amount + " USD");
        } catch (IOException e) {
            System.err.println("Error writing to transactions.csv file: " + e.getMessage());
        }
    }
    
    // Method to write output to the text file
    private void writeToFile(String output) {
        String fileName = "C:\\Users\\donal\\Downloads\\transactionsOutput.txt";
        try (PrintWriter writer = new PrintWriter(new FileWriter(fileName, true))) {
            writer.println(output);
        } catch (IOException e) {
            System.err.println("Error writing to transactionsOutput.txt file: " + e.getMessage());
        }
    }

    // Method to perform an internal audit
    @Override
    public void internalAudit() {
        lock.lock();
        try {
            // audit output
            String output = "*************************************************************************************************************\n"
                    + "INTERNAL BANK AUDITOR FINDS CURRENT ACCOUNT BALANCE TO BE: $" + balance
                    + "   Number of transactions since last Internal audit is: " + transactionCount + "\n"
                    + "*************************************************************************************************************";
            // Print to console and write to file
            System.out.println(output);
            writeToFile(output);
            // Reset transaction count after audit
            transactionCount = 0;
        } finally {
            lock.unlock();
        }
    }

    // Method to perform a treasury audit
    @Override
    public void treasuryAudit() {
        lock.lock();
        try {
            // audit output
            String output = "*************************************************************************************************************\n"
                    + "TREASURY DEPARTMENT AUDITOR FINDS CURRENT ACCOUNT BALANCE TO BE: $" + balance
                    + "   Number of transactions since last Treasury audit is: " + transactionCount + "\n"
                    + "*************************************************************************************************************";
            // Print to console and write to file
            System.out.println(output);
            writeToFile(output);
            // Reset transaction count after audit
            transactionCount = 0;
        } finally {
            lock.unlock();
        }
    }
}
