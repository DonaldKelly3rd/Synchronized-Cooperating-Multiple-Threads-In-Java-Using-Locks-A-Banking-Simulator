/* Donald Kelly
Course: CNT 4714 Spring 2024
Assignment title: Project 2 – Synchronized, Cooperating Threads Under Locking
Due Date: February 11, 2024
*/

package project2CNT4713;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class BankingSimulator {
    // 10 withdrawal threads, 5 depositor threads, and 2 auditor threads
    public static final int MAX_AGENTS = 17; // maximum number of banking agents, i.e. threads for the thread pool

    public static void main(String[] args) {
        // thread pool size 17
        ExecutorService application = Executors.newFixedThreadPool(MAX_AGENTS); 
        BankAccount jointAccount = new BankAccount(); // create a bank account to work with executor object

        try {
            System.out.println("*** SIMULATION BEGINS...");
            System.out.println();

            // Start Threads random order
            System.out.println("Deposit Agents\t\t\t Withdrawal Agents\t\t  Balance  Transaction Number");
            System.out.println("------------\t\t\t ------------\t\t----------\t\t\t----------");

            // Start all threads running
            for (int i = 0; i < 10; i++) {
                application.execute(new Withdraw(jointAccount));
            }

            for (int i = 0; i < 5; i++) {
                application.execute(new deposit(jointAccount));
            }

            application.execute(new InternalAudit(jointAccount));

        } catch (Exception exception) {
            exception.printStackTrace(); // something went wrong
        } finally {
            application.shutdown(); // terminate executor
        }
    }
}
