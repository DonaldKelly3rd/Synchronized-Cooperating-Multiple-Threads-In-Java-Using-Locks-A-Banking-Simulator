/* Donald Kelly
Course: CNT 4714 Spring 2024
Assignment title: Project 2 – Synchronized, Cooperating Threads Under Locking
Due Date: February 11, 2024
*/

package project2CNT4713;

import java.util.Random;
import java.util.concurrent.atomic.AtomicInteger;

public class deposit implements Runnable {
    private TheBank bank;
    private Random random;
    private static final int MAXSLEEPTIME = 1500;
    private static final AtomicInteger depositCounter = new AtomicInteger(0);
    private final int agentNumber;

    // deposit constructor
    public deposit(TheBank bank) {
        this.bank = bank;
        this.random = new Random();
        this.agentNumber = depositCounter.incrementAndGet();
    }

    public void run() {
        // Add logic to deposit money into the bank account
        while (true) {
            try {
                // Generate a random amount to deposit (between $1 and $500)
                int amount = random.nextInt(500) + 1;
                // Deposit the amount into the account
                bank.deposit(amount, "DT" + agentNumber);
                // Sleep for a random amount of time
                Thread.sleep(random.nextInt(MAXSLEEPTIME) + 1);
            } catch (InterruptedException exception) {
                System.out.println("Exception thrown depositing!");
            }
        }
    }
}
